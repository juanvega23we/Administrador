// lib/pages/productos/productos_page.dart

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../services/producto_service_admin.dart';
import '../../widgets/notificacion_personalizada.dart';
import 'widgets/producto_card.dart';
import 'widgets/producto_form.dart';
import 'widgets/actualizar_precios_dialog.dart'; // ← NUEVO

class ProductosPage extends StatefulWidget {
  const ProductosPage({super.key});

  @override
  State<ProductosPage> createState() => _ProductosPageState();
}

class _ProductosPageState extends State<ProductosPage>
    with TickerProviderStateMixin {
  final ProductoServiceAdmin _servicio = ProductoServiceAdmin();

  TabController? _tabController;
  List<String>   _categoriasActuales = [];
  bool           _actualizandoController = false;

  bool   _mostrandoBusqueda = false;
  String _textoBusqueda     = '';
  final TextEditingController _busquedaCtrl  = TextEditingController();
  final FocusNode             _busquedaFocus = FocusNode();

  List<Map<String, dynamic>> _todosLosProductos = [];
  bool _productosListos = false;

  static const String _tabTodo = 'Todo';

  @override
  void initState() {
    super.initState();
    _servicio.obtenerTodosLosProductos().listen((lista) {
      if (mounted) {
        setState(() {
          _todosLosProductos = lista;
          _productosListos   = true;
        });
      }
    });
  }

  @override
  void dispose() {
    _tabController?.dispose();
    _busquedaCtrl.dispose();
    _busquedaFocus.dispose();
    super.dispose();
  }

  List<String> _buildTabs(List<String> categorias) =>
      [_tabTodo, ...categorias];

  void _actualizarTabController(List<String> todasLasTabs) {
    if (_actualizandoController) return;

    final mismaLista =
        todasLasTabs.length == _categoriasActuales.length &&
            todasLasTabs.every((c) => _categoriasActuales.contains(c));

    if (mismaLista && _tabController != null) return;

    _actualizandoController = true;

    final indexActual = _tabController?.index ?? 0;
    final nuevoIndex =
        indexActual < todasLasTabs.length ? indexActual : 0;

    final controllerViejo = _tabController;
    final controllerNuevo = TabController(
      length: todasLasTabs.length,
      vsync: this,
      initialIndex: nuevoIndex,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) {
        controllerNuevo.dispose();
        _actualizandoController = false;
        return;
      }
      setState(() {
        _tabController          = controllerNuevo;
        _categoriasActuales     = List.from(todasLasTabs);
        _actualizandoController = false;
      });
      controllerViejo?.dispose();
    });
  }

  List<Map<String, dynamic>> _productosPorCategoria(String categoria) {
    final lista = categoria == _tabTodo
        ? _todosLosProductos
        : _todosLosProductos
            .where((p) => p['categoria'] == categoria)
            .toList();
    if (_textoBusqueda.isEmpty) return lista;
    final query = _textoBusqueda.toLowerCase();
    return lista.where((p) {
      final nombre   = (p['nombre']   ?? '').toString().toLowerCase();
      final cat      = (p['categoria'] ?? '').toString().toLowerCase();
      final subtexto = (p['subtexto'] ?? '').toString().toLowerCase();
      return nombre.contains(query) ||
             cat.contains(query) ||
             subtexto.contains(query);
    }).toList();
  }

  // ── Acciones ─────────────────────────────────────────────────
  Future<void> _cambiarEstado(String idProducto, bool nuevoEstado) async {
    final resultado = nuevoEstado
        ? await _servicio.activarProducto(idProducto)
        : await _servicio.desactivarProducto(idProducto);
    if (!mounted) return;
    NotificacionPersonalizada.mostrarSnack(
      context,
      mensaje: resultado['mensaje'],
      tipo: resultado['exito'] ? TipoNotificacion.exito : TipoNotificacion.error,
    );
  }

  Future<void> _eliminarProducto(Map<String, dynamic> producto) async {
    final confirmar = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Eliminar Producto'),
        content: Text(
          '¿Estás seguro de eliminar "${producto['nombre']}" permanentemente?\n\nEsta acción no se puede deshacer.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white),
            child: const Text('Eliminar'),
          ),
        ],
      ),
    );
    if (confirmar != true) return;
    final resultado =
        await _servicio.eliminarProductoPermanente(producto['id']);
    if (!mounted) return;
    NotificacionPersonalizada.mostrarSnack(
      context,
      mensaje: resultado['mensaje'],
      tipo: resultado['exito'] ? TipoNotificacion.exito : TipoNotificacion.error,
    );
  }

  void _mostrarDialogoCrearCategoria(
      BuildContext context, List<String> categorias) {
    final ctrlNombre  = TextEditingController();
    final ctrlPrefijo = TextEditingController();
    String iconoSel   = 'grain';

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlg) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Row(children: [
            Icon(Icons.add_box_rounded, color: Colors.teal),
            SizedBox(width: 8),
            Text('Nueva Categoría'),
          ]),
          content: SizedBox(
            width: 400,
            child: SingleChildScrollView(child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: ctrlNombre,
                  autofocus: true,
                  decoration: const InputDecoration(
                    labelText: 'Nombre de la categoría',
                    hintText: 'Ej: Lácteos',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.label_outline),
                  ),
                  textCapitalization: TextCapitalization.words,
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: ctrlPrefijo,
                  keyboardType: TextInputType.number,
                  maxLength: 2,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: const InputDecoration(
                    labelText: 'Prefijo (2 dígitos)',
                    hintText: 'Ej: 22',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.tag, color: Colors.teal),
                    counterText: '',
                    helperText: 'Productos con este prefijo se asignan aquí automáticamente',
                  ),
                ),
                const SizedBox(height: 16),
                Text('Ícono de la categoría',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600,
                        color: Colors.grey[700])),
                const SizedBox(height: 10),
                Wrap(spacing: 8, runSpacing: 8,
                  children: _iconosCategorias.entries.map((e) {
                    final sel = e.key == iconoSel;
                    return GestureDetector(
                      onTap: () => setDlg(() => iconoSel = e.key),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 150),
                        width: 52, height: 52,
                        decoration: BoxDecoration(
                          color: sel ? const Color(0xFF00695C).withOpacity(0.12) : Colors.grey[100],
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: sel ? const Color(0xFF00695C) : Colors.transparent,
                            width: 2),
                        ),
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(e.value, size: 22,
                              color: sel ? const Color(0xFF00695C) : Colors.grey[500]),
                        ]),
                      ),
                    );
                  }).toList(),
                ),
              ],
            )),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
            ElevatedButton.icon(
              icon: Icon(_iconoDesdeString(iconoSel), size: 16),
              label: const Text('Crear'),
              onPressed: () async {
                final nombre  = ctrlNombre.text.trim();
                final prefijo = ctrlPrefijo.text.trim();
                if (nombre.isEmpty) {
                  NotificacionPersonalizada.mostrarSnack(context,
                      mensaje: 'Ingresa el nombre de la categoría',
                      tipo: TipoNotificacion.error);
                  return;
                }
                if (prefijo.length != 2) {
                  NotificacionPersonalizada.mostrarSnack(context,
                      mensaje: 'El prefijo debe tener exactamente 2 dígitos',
                      tipo: TipoNotificacion.error);
                  return;
                }
                Navigator.pop(ctx);
                final resultado = await _servicio.crearCategoria(
                  nombre: nombre, prefijo: prefijo, icono: iconoSel);
                if (!mounted) return;
                NotificacionPersonalizada.mostrarSnack(context,
                    mensaje: resultado['mensaje'],
                    tipo: resultado['exito'] ? TipoNotificacion.exito : TipoNotificacion.error);
              },
              style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF00695C),
                  foregroundColor: Colors.white),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmarEliminarCategoria(
      BuildContext context, String categoria) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Eliminar Categoría'),
        content: Text(
          '¿Eliminar la categoría "$categoria"?\n\nLos productos de esta categoría seguirán visibles en la pestaña "Todo".',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(ctx);
              final resultado =
                  await _servicio.eliminarCategoria(categoria);
              if (!mounted) return;
              NotificacionPersonalizada.mostrarSnack(
                context,
                mensaje: resultado['mensaje'],
                tipo: resultado['exito']
                    ? TipoNotificacion.exito
                    : TipoNotificacion.error,
              );
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white),
            child: const Text('Eliminar'),
          ),
        ],
      ),
    );
  }

  // Íconos con temática de alimentos
  static const Map<String, IconData> _iconosCategorias = {
    'grain':         Icons.grain,
    'cake':          Icons.cake_rounded,
    'cookie':        Icons.cookie_rounded,
    'egg':           Icons.egg_alt_rounded,
    'water_drop':    Icons.water_drop_rounded,
    'icecream':      Icons.icecream,
    'bakery_dining': Icons.bakery_dining,
    'set_meal':      Icons.set_meal,
    'restaurant':    Icons.restaurant_rounded,
    'local_drink':   Icons.local_drink_rounded,
    'blender':       Icons.blender,
    'local_florist': Icons.local_florist_rounded,
    'science':       Icons.science_rounded,
    'kitchen':       Icons.kitchen_rounded,
    'lunch_dining':  Icons.lunch_dining,
    'emoji_food':    Icons.emoji_food_beverage_rounded,
    'inventory':     Icons.inventory_2_rounded,
    'star':          Icons.star_rounded,
    'category':      Icons.category_rounded,
    'label':         Icons.label_rounded,
  };

  static IconData _iconoDesdeString(String? nombre) =>
      _iconosCategorias[nombre] ?? Icons.category_rounded;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: _servicio.obtenerCategoriasStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Scaffold(body: Center(child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, size: 64, color: Colors.red),
              const SizedBox(height: 16),
              Text('Error: \${snapshot.error}'),
              const SizedBox(height: 16),
              ElevatedButton(onPressed: () => setState(() {}), child: const Text('Reintentar')),
            ])));
        }
        if (!snapshot.hasData) {
          return const Scaffold(body: Center(child: CircularProgressIndicator(color: Colors.teal)));
        }

        final categorias   = snapshot.data!;
        final catNombres   = categorias.map((c) => c['nombre'] as String).toList();
        final todasLasTabs = [_tabTodo, ...catNombres];

        if (_tabController == null || _categoriasActuales.isEmpty) {
          _tabController = TabController(length: todasLasTabs.length, vsync: this);
          _categoriasActuales = List.from(todasLasTabs);
        } else {
          _actualizarTabController(todasLasTabs);
        }

        final tabsParaMostrar = _categoriasActuales.isNotEmpty ? _categoriasActuales : todasLasTabs;

        if (_tabController == null || _tabController!.length != tabsParaMostrar.length) {
          return const Scaffold(body: Center(child: CircularProgressIndicator(color: Colors.teal)));
        }

        final tabIdx   = _tabController!.index.clamp(0, tabsParaMostrar.length - 1);
        final tabActual = tabsParaMostrar[tabIdx];
        final catInicial = tabActual == _tabTodo
            ? (catNombres.isNotEmpty ? catNombres.first : null)
            : tabActual;

        return Scaffold(
          backgroundColor: const Color(0xFFF7F8FA),
          body: Column(children: [

            // ══ HEADER con gradiente ══════════════════════════════
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF00574B), Color(0xFF00897B)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: SafeArea(bottom: false, child: Column(children: [
                // Título + acciones
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 16, 12),
                  child: Row(children: [
                    Expanded(
                      child: _mostrandoBusqueda
                          ? _SearchBar(
                              controller: _busquedaCtrl, focusNode: _busquedaFocus,
                              onChanged: (v) => setState(() => _textoBusqueda = v),
                              onClose: () => setState(() {
                                _mostrandoBusqueda = false; _textoBusqueda = ''; _busquedaCtrl.clear();
                              }))
                          : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              const Text('Gestionar Productos',
                                  style: TextStyle(color: Colors.white, fontSize: 20,
                                      fontWeight: FontWeight.w800, letterSpacing: -0.5)),
                              Text('${_todosLosProductos.length} productos en catálogo',
                                  style: TextStyle(color: Colors.white.withOpacity(0.65), fontSize: 12)),
                            ]),
                    ),
                    if (!_mostrandoBusqueda) ...[
                      _IconBtn(icon: Icons.price_change_rounded, tooltip: 'Actualizar precios',
                          onTap: () => ActualizarPreciosDialog.mostrar(context, servicio: _servicio)),
                      const SizedBox(width: 8),
                      _IconBtn(icon: Icons.search_rounded, tooltip: 'Buscar',
                          onTap: () {
                            setState(() => _mostrandoBusqueda = true);
                            Future.delayed(const Duration(milliseconds: 100), () => _busquedaFocus.requestFocus());
                          }),
                    ],
                  ]),
                ),

                // ── CATEGORÍAS: scroll horizontal con tarjetas ──────
                SizedBox(
                  height: 80,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                    children: [
                      // "Todo"
                      _CatChip(
                        label: 'Todo',
                        icon: Icons.apps_rounded,
                        count: _todosLosProductos.length,
                        selected: tabActual == _tabTodo,
                        onTap: () { _tabController?.animateTo(0); setState(() {}); },
                      ),
                      ...categorias.map((cat) {
                        final nombre = cat['nombre'] as String;
                        final icono  = _iconoDesdeString(cat['icono'] as String?);
                        final idx    = tabsParaMostrar.indexOf(nombre);
                        final cnt    = _productosPorCategoria(nombre).length;
                        return _CatChip(
                          label: nombre,
                          icon: icono,
                          count: cnt,
                          selected: tabActual == nombre,
                          onTap: () { if (idx >= 0) _tabController?.animateTo(idx); setState(() {}); },
                          onEdit: () => _mostrarDialogoEditarCategoria(context, cat),
                          onDelete: () => _confirmarEliminarCategoria(context, nombre),
                        );
                      }),
                      // Agregar
                      Padding(
                        padding: const EdgeInsets.only(right: 8, bottom: 0),
                        child: GestureDetector(
                          onTap: () => _mostrarDialogoCrearCategoria(context, catNombres),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: Colors.white.withOpacity(0.25), width: 1.2),
                            ),
                            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                              Icon(Icons.add_rounded, color: Colors.white.withOpacity(0.7), size: 22),
                              const SizedBox(height: 2),
                              Text('Nueva', style: TextStyle(
                                  fontSize: 10, color: Colors.white.withOpacity(0.6),
                                  fontWeight: FontWeight.w600)),
                            ]),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ])),
            ),

            // ══ BARRA INFO + LISTA ═══════════════════════════════
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

                // Info de categoría activa
                Container(
                  color: Colors.white,
                  padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
                  child: Row(children: [
                    Text(tabActual,
                        style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700,
                            color: Color(0xFF1B4332))),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                      decoration: BoxDecoration(
                        color: const Color(0xFF00695C).withOpacity(0.08),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text('${_productosPorCategoria(tabActual).length} productos',
                          style: const TextStyle(fontSize: 11, color: Color(0xFF00695C),
                              fontWeight: FontWeight.w600)),
                    ),
                  ]),
                ),
                const Divider(height: 1, thickness: 1, color: Color(0xFFEEF0F0)),

                // Lista
                Expanded(
                  child: !_productosListos
                      ? const Center(child: CircularProgressIndicator(color: Color(0xFF00897B)))
                      : TabBarView(
                          controller: _tabController,
                          physics: const NeverScrollableScrollPhysics(),
                          children: tabsParaMostrar.map((tab) {
                            final prods = _productosPorCategoria(tab);
                            if (prods.isEmpty) {
                              return _EmptyState(
                                texto: _textoBusqueda.isNotEmpty
                                    ? 'Sin resultados para "$_textoBusqueda"'
                                    : tab == _tabTodo ? 'No hay productos' : 'No hay productos en $tab',
                                accion: _textoBusqueda.isEmpty && tab != _tabTodo
                                    ? TextButton.icon(
                                        onPressed: () => ProductoForm.mostrar(context,
                                            categorias: catNombres, servicio: _servicio, categoriaInicial: tab),
                                        icon: const Icon(Icons.add_circle_outline),
                                        label: const Text('Agregar primero'))
                                    : null,
                              );
                            }
                            return ListView.builder(
                              padding: const EdgeInsets.fromLTRB(0, 6, 0, 100),
                              itemCount: prods.length,
                              itemBuilder: (_, i) => ProductoCard(
                                producto: prods[i],
                                categorias: catNombres,
                                enTabTodo: tab == _tabTodo,
                                servicio: _servicio,
                                onEditar: (p) => ProductoForm.mostrar(context,
                                    categorias: catNombres, servicio: _servicio, productoExistente: p),
                                onCambiarEstado: _cambiarEstado,
                                onEliminar: tab == _tabTodo ? _eliminarProducto : null,
                              ),
                            );
                          }).toList(),
                        ),
                ),
              ]),
            ),
          ]),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () {
              if (categorias.isEmpty) {
                NotificacionPersonalizada.mostrarSnack(context,
                    mensaje: 'Primero crea una categoría', tipo: TipoNotificacion.advertencia);
                return;
              }
              ProductoForm.mostrar(context, categorias: catNombres,
                  servicio: _servicio, categoriaInicial: catInicial);
            },
            backgroundColor: const Color(0xFF00897B),
            foregroundColor: Colors.white,
            elevation: 6,
            icon: const Icon(Icons.add_rounded),
            label: const Text('Nuevo Producto', style: TextStyle(fontWeight: FontWeight.w700)),
          ),
        );
      },
    );
  }

  // ── Diálogo editar categoría ─────────────────────────────────
  void _mostrarDialogoEditarCategoria(BuildContext context, Map<String, dynamic> cat) {
    final ctrlNombre  = TextEditingController(text: cat['nombre'] as String? ?? '');
    final ctrlPrefijo = TextEditingController(text: cat['prefijo'] as String? ?? '');
    String iconoSel   = cat['icono'] as String? ?? 'category';

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlg) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Row(children: [
            Icon(Icons.edit_rounded, color: Colors.teal), SizedBox(width: 8), Text('Editar Categoría'),
          ]),
          content: SizedBox(
            width: 380,
            child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: ctrlNombre, decoration: const InputDecoration(
                  labelText: 'Nombre', border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.label_outline))),
              const SizedBox(height: 12),
              TextField(controller: ctrlPrefijo,
                keyboardType: TextInputType.number, maxLength: 2,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: const InputDecoration(
                  labelText: 'Prefijo (2 dígitos)', border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.tag, color: Colors.teal), counterText: '')),
              const SizedBox(height: 16),
              Align(alignment: Alignment.centerLeft,
                child: Text('Ícono', style: TextStyle(fontSize: 13, color: Colors.grey[600]))),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8,
                children: _iconosCategorias.entries.map((e) {
                  final sel = e.key == iconoSel;
                  return GestureDetector(
                    onTap: () => setDlg(() => iconoSel = e.key),
                    child: AnimatedContainer(duration: const Duration(milliseconds: 150),
                      width: 44, height: 44,
                      decoration: BoxDecoration(
                        color: sel ? Colors.teal.withOpacity(0.15) : Colors.grey.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: sel ? Colors.teal : Colors.transparent, width: 2)),
                      child: Icon(e.value, size: 22, color: sel ? Colors.teal : Colors.grey[600])),
                  );
                }).toList()),
            ])),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
            ElevatedButton.icon(
              icon: const Icon(Icons.save_rounded, size: 16),
              label: const Text('Guardar'),
              onPressed: () async {
                final nombre = ctrlNombre.text.trim();
                if (nombre.isEmpty) return;
                Navigator.pop(ctx);
                final r = await _servicio.editarCategoria(
                  id: cat['id'] as String,
                  nombre: nombre,
                  prefijo: ctrlPrefijo.text.trim().length == 2 ? ctrlPrefijo.text.trim() : null,
                  icono: iconoSel,
                );
                if (!mounted) return;
                NotificacionPersonalizada.mostrarSnack(context, mensaje: r['mensaje'],
                    tipo: r['exito'] ? TipoNotificacion.exito : TipoNotificacion.error);
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.teal, foregroundColor: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final String  texto;
  final Widget? accion;

  const _EmptyState({required this.texto, this.accion});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.inventory_2_outlined, size: 80, color: Colors.grey[400]),
          const SizedBox(height: 16),
          Text(texto,
              style: TextStyle(fontSize: 18, color: Colors.grey[600])),
          if (accion != null) ...[
            const SizedBox(height: 8),
            accion!,
          ],
        ],
      ),
    );
  }
}

class _SearchBar extends StatelessWidget {
  final TextEditingController controller;
  final FocusNode focusNode;
  final ValueChanged<String> onChanged;
  final VoidCallback onClose;

  const _SearchBar({
    required this.controller,
    required this.focusNode,
    required this.onChanged,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(999),
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: Colors.teal.shade600, width: 2),
        ),
        child: Row(
          children: [
            GestureDetector(
              onTap: onClose,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Icon(Icons.close, color: Colors.teal.shade600, size: 20),
              ),
            ),
            Expanded(
              child: TextField(
                controller: controller,
                focusNode: focusNode,
                autofocus: true,
                style: const TextStyle(color: Colors.black87, fontSize: 15),
                cursorColor: Colors.teal,
                decoration: InputDecoration(
                  hintText: 'Buscar producto...',
                  hintStyle: TextStyle(color: Colors.grey[400]),
                  border: InputBorder.none,
                  isDense: true,
                  contentPadding: const EdgeInsets.symmetric(vertical: 12),
                ),
                onChanged: onChanged,
              ),
            ),
            const SizedBox(width: 16),
          ],
        ),
      ),
    );
  }
}




// ── Chip de categoría con ícono + contador ───────────────────
class _CatChip extends StatelessWidget {
  final String     label;
  final IconData   icon;
  final int        count;
  final bool       selected;
  final VoidCallback onTap;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  const _CatChip({
    required this.label, required this.icon, required this.count,
    required this.selected, required this.onTap,
    this.onEdit, this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
          decoration: BoxDecoration(
            color: selected ? Colors.white : Colors.white.withOpacity(0.13),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: selected ? Colors.white : Colors.white.withOpacity(0.22),
              width: 1.4,
            ),
            boxShadow: selected ? [
              BoxShadow(color: Colors.black.withOpacity(0.18),
                  blurRadius: 10, offset: const Offset(0, 4)),
            ] : [],
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 16,
                color: selected ? const Color(0xFF00574B) : Colors.white),
            const SizedBox(width: 7),
            Column(crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(label, style: TextStyle(
                fontSize: 12, fontWeight: FontWeight.w700,
                color: selected ? const Color(0xFF00574B) : Colors.white,
              )),
              Text('$count items', style: TextStyle(
                fontSize: 9.5,
                color: selected
                    ? const Color(0xFF00574B).withOpacity(0.6)
                    : Colors.white.withOpacity(0.55),
                fontWeight: FontWeight.w500,
              )),
            ]),
            if (onEdit != null) ...[
              const SizedBox(width: 10),
              Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                GestureDetector(onTap: onEdit,
                  child: Icon(Icons.edit_rounded, size: 11,
                      color: selected
                          ? const Color(0xFF00574B).withOpacity(0.45)
                          : Colors.white.withOpacity(0.45))),
                const SizedBox(height: 3),
                GestureDetector(onTap: onDelete,
                  child: Icon(Icons.close_rounded, size: 11,
                      color: Colors.red.withOpacity(0.65))),
              ]),
            ],
          ]),
        ),
      ),
    );
  }
}

// ── Botón ícono del header ────────────────────────────────────
class _IconBtn extends StatelessWidget {
  final IconData icon; final String tooltip; final VoidCallback onTap;
  const _IconBtn({required this.icon, required this.tooltip, required this.onTap});

  @override
  Widget build(BuildContext context) => Tooltip(
    message: tooltip,
    child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(10),
      child: Container(width: 40, height: 40,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.15),
          borderRadius: BorderRadius.circular(10)),
        child: Icon(icon, color: Colors.white, size: 20))),
  );
}